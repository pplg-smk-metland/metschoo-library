import{b2 as s}from"./CXxQdrZS.js";const u=()=>{var e;return(e=s().$supabase)==null?void 0:e.client};export{u};
