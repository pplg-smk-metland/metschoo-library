import{_ as ge}from"./DsOxU59O.js";import{s as ve,_ as ye}from"./DhAa_UuV.js";import{a as we,b as Y,u as je,_ as _e}from"./DT0iWGju.js";import{B as Le,C as O,a1 as D,ak as Ce,a3 as Z,ar as Se,ad as Be,al as ze,z as Q,L as Ae,o as u,k as B,w as z,b,am as Ee,E as k,n as Oe,c as w,D as H,F as oe,G as X,H as ae,l as R,a as o,t as p,A as ee,f as Re,h as Ie,J as Pe,I as De,as as He,r as L,i as K,q as ne,j as i,d as te,x as ie,p as Te,e as Ke}from"./CXxQdrZS.js";import{u as Fe}from"./CQtl1A4u.js";import{e as xe,h as $e,i as Ve,r as Ge,f as Ue,j as Ne}from"./C4W4ZJUk.js";import{Z as F,b as qe}from"./CoaV5O8P.js";import{C as We,s as Me}from"./DxZhgOgB.js";import{F as Je}from"./DndZ3lar.js";import{O as Ye}from"./ByYZOOkV.js";import{s as Ze}from"./DKnyOLa7.js";import{s as Qe}from"./DGQ916fz.js";import{s as Xe}from"./AQXXMypN.js";import{_ as en}from"./DlAUqK2U.js";import"./BkzeEWCu.js";import"./BaMA0pAB.js";import"./Bzi0Jkdt.js";import"./DspqganC.js";var nn=function(e){var t=e.dt;return`
.p-confirmpopup {
    position: absolute;
    margin-top: `.concat(t("confirmpopup.gutter"),`;
    top: 0;
    left: 0;
    background: `).concat(t("confirmpopup.background"),`;
    color: `).concat(t("confirmpopup.color"),`;
    border: 1px solid `).concat(t("confirmpopup.border.color"),`;
    border-radius: `).concat(t("confirmpopup.border.radius"),`;
    box-shadow: `).concat(t("confirmpopup.shadow"),`;
}

.p-confirmpopup-content {
    display: flex;
    align-items: center;
    padding: `).concat(t("confirmpopup.content.padding"),`;
    gap: `).concat(t("confirmpopup.content.gap"),`;
}

.p-confirmpopup-icon {
    font-size: `).concat(t("confirmpopup.icon.size"),`;
    width: `).concat(t("confirmpopup.icon.size"),`;
    height: `).concat(t("confirmpopup.icon.size"),`;
    color: `).concat(t("confirmpopup.icon.color"),`;
}

.p-confirmpopup-footer {
    display: flex;
    justify-content: flex-end;
    gap: `).concat(t("confirmpopup.footer.gap"),`;
    padding: `).concat(t("confirmpopup.footer.padding"),`;
}

.p-confirmpopup-footer button {
    width: auto;
}

.p-confirmpopup-footer button:last-child {
    margin: 0;
}

.p-confirmpopup-flipped {
    margin-top: calc(`).concat(t("confirmpopup.gutter"),` * -1);
    margin-bottom: `).concat(t("confirmpopup.gutter"),`;
}

.p-confirmpopup-enter-from {
    opacity: 0;
    transform: scaleY(0.8);
}

.p-confirmpopup-leave-to {
    opacity: 0;
}

.p-confirmpopup-enter-active {
    transition: transform 0.12s cubic-bezier(0, 0, 0.2, 1), opacity 0.12s cubic-bezier(0, 0, 0.2, 1);
}

.p-confirmpopup-leave-active {
    transition: opacity 0.1s linear;
}

.p-confirmpopup:after,
.p-confirmpopup:before {
    bottom: 100%;
    left: calc(`).concat(t("confirmpopup.arrow.offset")," + ").concat(t("confirmpopup.arrow.left"),`);
    content: " ";
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
}

.p-confirmpopup:after {
    border-width: calc(`).concat(t("confirmpopup.gutter"),` - 2px);
    margin-left: calc(-1 * (`).concat(t("confirmpopup.gutter"),` - 2px));
    border-style: solid;
    border-color: transparent;
    border-bottom-color: `).concat(t("confirmpopup.background"),`;
}

.p-confirmpopup:before {
    border-width: `).concat(t("confirmpopup.gutter"),`;
    margin-left: calc(-1 * `).concat(t("confirmpopup.gutter"),`);
    border-style: solid;
    border-color: transparent;
    border-bottom-color: `).concat(t("confirmpopup.border.color"),`;
}

.p-confirmpopup-flipped:after,
.p-confirmpopup-flipped:before {
    bottom: auto;
    top: 100%;
}

.p-confirmpopup-flipped:after {
    border-bottom-color: transparent;
    border-top-color: `).concat(t("confirmpopup.background"),`;
}

.p-confirmpopup-flipped:before {
    border-bottom-color: transparent;
    border-top-color: `).concat(t("confirmpopup.border.color"),`;
}
`)},tn={root:"p-confirmpopup p-component",content:"p-confirmpopup-content",icon:"p-confirmpopup-icon",message:"p-confirmpopup-message",footer:"p-confirmpopup-footer",pcRejectButton:"p-confirmpopup-reject-button",pcAcceptButton:"p-confirmpopup-accept-button"},on=Le.extend({name:"confirmpopup",theme:nn,classes:tn}),an={name:"BaseConfirmPopup",extends:Me,props:{group:String},style:on,provide:function(){return{$pcConfirmPopup:this,$parentInstance:this}}},se={name:"ConfirmPopup",extends:an,inheritAttrs:!1,data:function(){return{visible:!1,confirmation:null,autoFocusAccept:null,autoFocusReject:null,target:null}},target:null,outsideClickListener:null,scrollHandler:null,resizeListener:null,container:null,confirmListener:null,closeListener:null,mounted:function(){var e=this;this.confirmListener=function(t){t&&t.group===e.group&&(e.confirmation=t,e.target=t.target,e.confirmation.onShow&&e.confirmation.onShow(),e.visible=!0)},this.closeListener=function(){e.visible=!1,e.confirmation=null},O.on("confirm",this.confirmListener),O.on("close",this.closeListener)},beforeUnmount:function(){O.off("confirm",this.confirmListener),O.off("close",this.closeListener),this.unbindOutsideClickListener(),this.scrollHandler&&(this.scrollHandler.destroy(),this.scrollHandler=null),this.unbindResizeListener(),this.container&&(F.clear(this.container),this.container=null),this.target=null,this.confirmation=null},methods:{accept:function(){this.confirmation.accept&&this.confirmation.accept(),this.visible=!1},reject:function(){this.confirmation.reject&&this.confirmation.reject(),this.visible=!1},onHide:function(){this.confirmation.onHide&&this.confirmation.onHide(),this.visible=!1},onAcceptKeydown:function(e){(e.code==="Space"||e.code==="Enter"||e.code==="NumpadEnter")&&(this.accept(),D(this.target),e.preventDefault())},onRejectKeydown:function(e){(e.code==="Space"||e.code==="Enter"||e.code==="NumpadEnter")&&(this.reject(),D(this.target),e.preventDefault())},onEnter:function(e){this.autoFocusAccept=this.confirmation.defaultFocus===void 0||this.confirmation.defaultFocus==="accept",this.autoFocusReject=this.confirmation.defaultFocus==="reject",this.target=document.activeElement,this.bindOutsideClickListener(),this.bindScrollListener(),this.bindResizeListener(),F.set("overlay",e,this.$primevue.config.zIndex.overlay)},onAfterEnter:function(){this.focus()},onLeave:function(){this.autoFocusAccept=null,this.autoFocusReject=null,D(this.target),this.target=null,this.unbindOutsideClickListener(),this.unbindScrollListener(),this.unbindResizeListener()},onAfterLeave:function(e){F.clear(e)},alignOverlay:function(){Ce(this.container,this.target,!1);var e=Z(this.container),t=Z(this.target),j=0;e.left<t.left&&(j=t.left-e.left),this.container.style.setProperty(Se("confirmpopup.arrow.left").name,"".concat(j,"px")),e.top<t.top&&(this.container.setAttribute("data-p-confirmpopup-flipped","true"),!this.isUnstyled&&Be(this.container,"p-confirmpopup-flipped"))},bindOutsideClickListener:function(){var e=this;this.outsideClickListener||(this.outsideClickListener=function(t){e.visible&&e.container&&!e.container.contains(t.target)&&!e.isTargetClicked(t)?(e.confirmation.onHide&&e.confirmation.onHide(),e.visible=!1):e.alignOverlay()},document.addEventListener("click",this.outsideClickListener))},unbindOutsideClickListener:function(){this.outsideClickListener&&(document.removeEventListener("click",this.outsideClickListener),this.outsideClickListener=null)},bindScrollListener:function(){var e=this;this.scrollHandler||(this.scrollHandler=new We(this.target,function(){e.visible&&(e.visible=!1)})),this.scrollHandler.bindScrollListener()},unbindScrollListener:function(){this.scrollHandler&&this.scrollHandler.unbindScrollListener()},bindResizeListener:function(){var e=this;this.resizeListener||(this.resizeListener=function(){e.visible&&!ze()&&(e.visible=!1)},window.addEventListener("resize",this.resizeListener))},unbindResizeListener:function(){this.resizeListener&&(window.removeEventListener("resize",this.resizeListener),this.resizeListener=null)},focus:function(){var e=this.container.querySelector("[autofocus]");e&&e.focus({preventScroll:!0})},isTargetClicked:function(e){return this.target&&(this.target===e.target||this.target.contains(e.target))},containerRef:function(e){this.container=e},onOverlayClick:function(e){Ye.emit("overlay-click",{originalEvent:e,target:this.target})},onOverlayKeydown:function(e){e.code==="Escape"&&(O.emit("close",this.closeListener),D(this.target))}},computed:{message:function(){return this.confirmation?this.confirmation.message:null},acceptLabel:function(){if(this.confirmation){var e,t=this.confirmation;return t.acceptLabel||((e=t.acceptProps)===null||e===void 0?void 0:e.label)||this.$primevue.config.locale.accept}return this.$primevue.config.locale.accept},rejectLabel:function(){if(this.confirmation){var e,t=this.confirmation;return t.rejectLabel||((e=t.rejectProps)===null||e===void 0?void 0:e.label)||this.$primevue.config.locale.reject}return this.$primevue.config.locale.reject},acceptIcon:function(){var e;return this.confirmation?this.confirmation.acceptIcon:(e=this.confirmation)!==null&&e!==void 0&&e.acceptProps?this.confirmation.acceptProps.icon:null},rejectIcon:function(){var e;return this.confirmation?this.confirmation.rejectIcon:(e=this.confirmation)!==null&&e!==void 0&&e.rejectProps?this.confirmation.rejectProps.icon:null}},components:{Button:ve,Portal:qe},directives:{focustrap:Je}},sn=["aria-modal"];function rn(n,e,t,j,s,r){var A=Q("Button"),T=Q("Portal"),c=Ae("focustrap");return u(),B(T,null,{default:z(function(){return[b(Ee,k({name:"p-confirmpopup",onEnter:r.onEnter,onAfterEnter:r.onAfterEnter,onLeave:r.onLeave,onAfterLeave:r.onAfterLeave},n.ptm("transition")),{default:z(function(){var C,f,_;return[s.visible?Oe((u(),w("div",k({key:0,ref:r.containerRef,role:"alertdialog",class:n.cx("root"),"aria-modal":s.visible,onClick:e[2]||(e[2]=function(){return r.onOverlayClick&&r.onOverlayClick.apply(r,arguments)}),onKeydown:e[3]||(e[3]=function(){return r.onOverlayKeydown&&r.onOverlayKeydown.apply(r,arguments)})},n.ptmi("root")),[n.$slots.container?H(n.$slots,"container",{key:0,message:s.confirmation,acceptCallback:r.accept,rejectCallback:r.reject}):(u(),w(oe,{key:1},[n.$slots.message?(u(),B(X(n.$slots.message),{key:1,message:s.confirmation},null,8,["message"])):(u(),w("div",k({key:0,class:n.cx("content")},n.ptm("content")),[H(n.$slots,"icon",{},function(){return[n.$slots.icon?(u(),B(X(n.$slots.icon),{key:0,class:ae(n.cx("icon"))},null,8,["class"])):s.confirmation.icon?(u(),w("span",k({key:1,class:[s.confirmation.icon,n.cx("icon")]},n.ptm("icon")),null,16)):R("",!0)]}),o("span",k({class:n.cx("message")},n.ptm("message")),p(s.confirmation.message),17)],16)),o("div",k({class:n.cx("footer")},n.ptm("footer")),[b(A,k({class:[n.cx("pcRejectButton"),s.confirmation.rejectClass],autofocus:s.autoFocusReject,unstyled:n.unstyled,size:((C=s.confirmation.rejectProps)===null||C===void 0?void 0:C.size)||"small",text:((f=s.confirmation.rejectProps)===null||f===void 0?void 0:f.text)||!1,onClick:e[0]||(e[0]=function(S){return r.reject()}),onKeydown:r.onRejectKeydown},s.confirmation.rejectProps,{label:r.rejectLabel,pt:n.ptm("pcRejectButton")}),ee({_:2},[r.rejectIcon||n.$slots.rejecticon?{name:"icon",fn:z(function(S){return[H(n.$slots,"rejecticon",{},function(){return[o("span",k({class:[r.rejectIcon,S.class]},n.ptm("pcRejectButton").icon,{"data-pc-section":"rejectbuttonicon"}),null,16)]})]}),key:"0"}:void 0]),1040,["class","autofocus","unstyled","size","text","onKeydown","label","pt"]),b(A,k({class:[n.cx("pcAcceptButton"),s.confirmation.acceptClass],autofocus:s.autoFocusAccept,unstyled:n.unstyled,size:((_=s.confirmation.acceptProps)===null||_===void 0?void 0:_.size)||"small",onClick:e[1]||(e[1]=function(S){return r.accept()}),onKeydown:r.onAcceptKeydown},s.confirmation.acceptProps,{label:r.acceptLabel,pt:n.ptm("pcAcceptButton")}),ee({_:2},[r.acceptIcon||n.$slots.accepticon?{name:"icon",fn:z(function(S){return[H(n.$slots,"accepticon",{},function(){return[o("span",k({class:[r.acceptIcon,S.class]},n.ptm("pcAcceptButton").icon,{"data-pc-section":"acceptbuttonicon"}),null,16)]})]}),key:"0"}:void 0]),1040,["class","autofocus","unstyled","size","onKeydown","label","pt"])],16)],64))],16,sn)),[[c]]):R("",!0)]}),_:3},16,["onEnter","onAfterEnter","onLeave","onAfterLeave"])]}),_:3})}se.render=rn;const g=n=>(Te("data-v-00acb603"),n=n(),Ke(),n),cn={key:0,class:"not-found"},ln=g(()=>o("h1",null,"Tidak ada buku!",-1)),un=g(()=>o("p",null,"Bukunya ga ada brok",-1)),pn=[ln,un],mn={key:2,class:"main-section grid grid-cols-1 md:grid-cols-6 md:grid-rows-2 gap-4 justify-items-start"},fn={class:"col-span-1 md:col-span-2 md:row-span-2 place-self-center relative dark:brightness-75 z-0"},dn=["src"],bn=["src"],hn={class:"buku__info col-span-1 md:col-span-4"},kn={class:"judul max-w-5xl"},gn={class:"text-slate-700 dark:text-slate-400"},vn={class:"button-container"},yn={class:"px-4 pt-4"},wn={class:"px-4 pb-4 flex gap-2"},jn={class:"md:col-span-4"},_n=g(()=>o("h2",null,"Informasi bibliografi",-1)),Ln={class:"tabel-bibliografi"},Cn=g(()=>o("td",null,"judul",-1)),Sn=g(()=>o("td",null,"Penulis",-1)),Bn=g(()=>o("td",null,"ISBN",-1)),zn=g(()=>o("td",null,"Penerbit",-1)),An=g(()=>o("p",null,"Saya akan mengembalikan buku ini pada...",-1)),En={class:"font-bold"},On=["datetime"],Rn={key:1},In=g(()=>o("h2",null,"Ups, ada yang salah nih.",-1)),Pn=g(()=>o("p",null,"Silahkan coba lagi, atau hubungi admin.",-1)),Dn=Re({__name:"[isbn]",setup(n){const e=Fe(),j=Ie().params.isbn,s=Pe(),r=De(),A=He(),T=L(!1),{buku:c}=we(),C=L("");K(async()=>{try{c.value=await xe(j)}catch(l){console.error(l),c.value=null,s.add({severity:"error",summary:"Gagal",detail:"Gagal menemukan buku.",life:1e4})}C.value=await $e(j)});const f=L(null);K(async()=>{try{f.value=await Y(j),_.value=await S(j)}catch(l){console.error(l)}});const _=L(!1);async function S(l){try{const{count:a,error:m}=await e.from("wishlist").select("no_isbn",{count:"exact",head:!0}).eq("no_isbn",l);if(m)throw m;return a?a!==null&&a!==0:!1}catch(a){return console.trace(a),!1}}const E=L(!1),{dialog:I}=je(),v=L(new Date),re=ne(()=>v.value?Ue(v.value,{dateStyle:"full"}):""),ce=ne(()=>v.value>new Date);function le(){if(!A.value)return s.add({severity:"warn",summary:"Tidak bisa meminjam buku",detail:"kalau mau pinjam buku, buat akun dulu ya.",life:1e4});E.value=!0}async function ue({judul:l,no_isbn:a},m){if(window.confirm(`Beneran mau pinjem buku ${l}?`))try{_.value&&await e.from("wishlist").delete().eq("no_isbn",a),await Ne(a,m),s.add({severity:"success",summary:"Sukses meminjam buku",detail:`sukses meminjam buku ${l}`,life:1e4}),E.value=!1}catch(y){console.error(y.message),s.add({severity:"error",summary:"Gagal meminjam buku",detail:"Gagal meminjam buku, coba lagi nanti.",life:1e4})}}async function pe({judul:l},a){if(!window.confirm(`apakah anda ingin membatalkan peminjaman ${l}?`))return s.add({severity:"info",summary:"Tidak jadi",detail:"Tidak jadi membatalkan peminjaman buku.",life:1e4});try{await Ve(a),s.add({severity:"success",summary:"Sukses!",detail:`Sukses membatalkan peminjaman buku ${l}.`,life:1e4})}catch(m){console.error(m),s.add({severity:"error",summary:"Gagal!",detail:"gagal membatalkan peminjaman buku! Silahkan coba lagi nanti.",life:1e4})}}async function me({judul:l},a){try{await Ge(a),s.add({severity:"success",summary:"Sukses!",detail:`sukses mengembalikan buku ${l}`,life:1e4})}catch(m){console.error(m.message),s.add({severity:"error",summary:"Gagal",detail:`Gagal mengembalikan buku! ${m.message}`,life:1e4})}}const P=L(!1);function fe(l,a){r.require({target:a.currentTarget,header:"Konfirmasi wishlist",message:"Apakah anda mau menambahkan buku ini ke dalam wishlist?",group:"headless",accept:async()=>{await de(l)},onShow:()=>P.value=!0,onHide:()=>P.value=!1})}async function de({no_isbn:l}){if(!A.value){s.add({severity:"warn",summary:"gagal memasukkan buku ke wishlist",detail:"silahkan masuk jika anda ingin menambahkan buku ke dalam wishlist"});return}try{const{data:a,error:m}=await e.from("wishlist").insert({no_isbn:l});if(m)throw m;return _.value=!0,s.add({severity:"success",summary:"Sukses",detail:"Sukses menambahkan buku ke dalam wishlist",life:5e3}),a}catch(a){s.add({severity:"error",summary:"gagal",detail:"Ada yang salah ketika menambahkan buku ke dalam wishlist. Silahkan coba beberapa saat lagi."}),console.error(a.message)}}async function be(l){try{f.value=await Y(l.new.no_isbn)}catch(a){I.value.open("Gagal mengambil data peminjaman, silahkan coba lagi."),console.error(a)}}e.channel("peminjaman").on("postgres_changes",{event:"*",schema:"public",table:"peminjaman"},be).subscribe();const x=L(!1);return K(()=>x.value=!0),(l,a)=>{var $,V,G,U,N,q,W,M,J;const m=ge,y=ye,he=_e;return u(),w(oe,null,[i(c)?R("",!0):(u(),w("div",cn,pn)),i(T)?(u(),B(m,{key:1})):i(c)&&i(x)?(u(),w("section",mn,[o("figure",fn,[o("img",{class:"buku__gambar",src:i(C),alt:"",width:"400",height:"600"},null,8,dn),o("img",{class:"buku__gambar buku__gambar--bayangan",src:i(C),alt:"",width:"400",height:"600"},null,8,bn)]),o("figcaption",hn,[o("h1",kn,p(i(c).judul),1),o("p",gn,[o("span",null,p(i(c).penulis),1),te(" - "),o("span",null,p(i(c).tahun_terbit),1)]),o("p",null,p(i(c).penerbit)+" - "+p(i(c).alamat_terbit),1),o("p",null,[te(" Jumlah tersedia: "),o("span",{class:ae(["font-bold",{"text-red":i(c).jumlah_exspl===0}])},p(i(c).jumlah_exspl),3)]),o("div",vn,[($=i(f))!=null&&$.isBorrowable?(u(),B(y,{key:0,fill:"",label:"Pinjam buku",onClick:le})):(u(),B(y,{key:1,disabled:!((V=i(f))!=null&&V.isCancellable),severity:"danger",label:"batalkan peminjaman",onClick:a[0]||(a[0]=d=>{var h;return pe(i(c),(h=i(f))==null?void 0:h.id)})},null,8,["disabled"])),(G=i(f))!=null&&G.isReturnable?(u(),B(y,{key:2,disabled:!((U=i(f))!=null&&U.isReturnable),fill:"",label:"kembalikan buku",onClick:a[1]||(a[1]=d=>{var h;return me(i(c),(h=i(f))==null?void 0:h.id)})},null,8,["disabled"])):R("",!0),b(i(se),{group:"headless","aria-label":"popup"},{container:z(({message:d,acceptCallback:h,rejectCallback:ke})=>[o("section",yn,[o("h3",null,p(d.header),1),o("p",null,p(d.message),1)]),o("section",wn,[b(y,{label:"Tidak",onClick:ke},null,8,["onClick"]),b(y,{label:"Ya",fill:"",onClick:h},null,8,["onClick"])])]),_:1}),b(i(Ze),{position:"top-right"}),b(y,{disabled:i(_)||!((N=i(f))!=null&&N.isBorrowable),"aria-expanded":i(P),"aria-controls":i(P)?"confirm":null,label:"tambahkan ke wishlist",onClick:a[2]||(a[2]=d=>fe(i(c),d))},null,8,["disabled","aria-expanded","aria-controls"])])]),o("article",jn,[_n,o("table",Ln,[o("tbody",null,[o("tr",null,[Cn,o("td",null,p((q=i(c))==null?void 0:q.judul),1)]),o("tr",null,[Sn,o("td",null,p((W=i(c))==null?void 0:W.penulis),1)]),o("tr",null,[Bn,o("td",null,p((M=i(c))==null?void 0:M.no_isbn),1)]),o("tr",null,[zn,o("td",null,p((J=i(c))==null?void 0:J.penerbit),1)])])])]),b(i(Xe),{visible:i(E),"onUpdate:visible":a[5]||(a[5]=d=>ie(E)?E.value=d:null),modal:"",header:"Mau dikembalikan kapan"},{default:z(()=>{var d;return[An,b(i(Qe),{modelValue:i(v),"onUpdate:modelValue":a[3]||(a[3]=h=>ie(v)?v.value=h:null),"min-date":new Date},null,8,["modelValue","min-date"]),o("p",En,[i(v)?(u(),w("time",{key:0,datetime:(d=i(v))==null?void 0:d.toISOString()},p(i(re)),9,On)):(u(),w("span",Rn," pilih dulu tanggalnya. "))]),b(y,{disabled:!i(ce),label:"Pinjam buku",fill:"",onClick:a[4]||(a[4]=h=>ue({...i(c)},i(v)))},null,8,["disabled"])]}),_:1},8,["visible"])])):R("",!0),b(he,{"is-open":i(I).isOpen,onDialogClose:a[6]||(a[6]=d=>i(I).close())},{default:z(()=>[In,o("p",null,p(i(I).message),1),Pn]),_:1},8,["is-open"])],64)}}}),et=en(Dn,[["__scopeId","data-v-00acb603"]]);export{et as default};
