export default {
    content: 'p-5 bg-surface-0 dark:bg-surface-900 border border-t-0 border-surface-200 dark:border-surface-700 text-surface-700 dark:text-surface-0/80'
};
