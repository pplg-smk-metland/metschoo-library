export default {
    root: 'relative flex justify-between items-center m-0 p-0 list-none overflow-x-auto'
};
