export default {
    root: 'px-2 pt-3.5 pb-[1.125rem]'
};
